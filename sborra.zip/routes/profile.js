const express = require('express');
const router = express.Router();
const db = require('../db');

function validateUserPayload(body, { partial = false } = {}) {
  const errors = [];
  const { name, email, age } = body;

  if (!partial || name !== undefined) {
    if (typeof name !== 'string' || !name.trim()) {
      errors.push('name is required and must be a non-empty string');
    }
  }

  if (!partial || email !== undefined) {
    if (typeof email !== 'string' || !email.trim()) {
      errors.push('email is required and must be a non-empty string');
    }
  }

  if (!partial || age !== undefined) {
    const parsedAge = Number(age);
    if (!Number.isInteger(parsedAge) || parsedAge < 0) {
      errors.push('age is required and must be a non-negative integer');
    }
  }

  return errors;
}

router.post('/profile', async (req, res) => {
  try {
    const errors = validateUserPayload(req.body);
    if (errors.length) {
      return res.status(400).json({ errors });
    }

    const { name, email, age } = req.body;
    const now = new Date();

    const insertQuery = `
      INSERT INTO users (name, email, age, created_at, updated_at)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING id, name, email, age, created_at, updated_at;
    `;

    const { rows } = await db.query(insertQuery, [name.trim(), email.trim(), Number(age), now, now]);

    return res.status(201).json(rows[0]);
  } catch (err) {
    console.error('Error creating profile:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

router.get('/profile/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ error: 'Invalid id parameter' });
    }

    const { rows } = await db.query(
      'SELECT id, name, email, age, created_at, updated_at FROM users WHERE id = $1',
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    return res.json(rows[0]);
  } catch (err) {
    console.error('Error fetching profile:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

router.put('/profile/:id', async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ error: 'Invalid id parameter' });
    }

    const errors = validateUserPayload(req.body);
    if (errors.length) {
      return res.status(400).json({ errors });
    }

    const { name, email, age } = req.body;
    const now = new Date();

    const updateQuery = `
      UPDATE users
      SET name = $1,
          email = $2,
          age = $3,
          updated_at = $4
      WHERE id = $5
      RETURNING id, name, email, age, created_at, updated_at;
    `;

    const { rows } = await db.query(updateQuery, [name.trim(), email.trim(), Number(age), now, id]);

    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    return res.json(rows[0]);
  } catch (err) {
    console.error('Error updating profile:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
