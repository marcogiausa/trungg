"use client";

import { useState, useEffect } from "react";
import { ArrowLeft, MessageSquare, GraduationCap, MapPin, Calendar, BookOpen } from "lucide-react";
import { RadialBar, RadialBarChart } from "recharts";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import Link from "next/link";
import { useParams } from "next/navigation";

// Mock data database - in a real app this would come from an API or database
const GENIUS_DATA: Record<string, any> = {
  "1": {
    name: "Sara Rossi",
    role: "STEM",
    university: "Università di Bologna",
    degree: "Computer Science (BSc)",
    year: "2nd year",
    support: "Tuition & living costs",
    description: "I am in my second year of Computer Science and looking for financial support to cover tuition and living costs while I focus on my studies. I am passionate about AI and want to specialize in machine learning.",
    stats: { field: 53, finances: 19, behaviour: 28 }
  },
  "2": {
    name: "Luca Bianchi",
    role: "Business",
    university: "Università Bocconi",
    degree: "Economics and Management",
    year: "1st year",
    support: "Accommodation & books",
    description: "I have just started my degree in Economics and I am looking for support to afford accommodation in Milano and the study materials I need. My goal is to work in sustainable finance.",
    stats: { field: 33, finances: 34, behaviour: 33 }
  }
};

export default function GeniusProfilePage() {
  const params = useParams();
  // Handle potential array or string for params.id
  const id = Array.isArray(params?.id) ? params.id[0] : params?.id;
  const genius = id ? GENIUS_DATA[id] : null;

  if (!genius) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-50">
        <p className="text-slate-500">Genius not found</p>
        <Link href="/genius">
          <Button variant="outline">Back to list</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-6 py-8 bg-slate-50">
      <div className="mx-auto max-w-5xl space-y-8">
        {/* Header Navigation */}
        <div className="flex items-center gap-4">
          <Link href="/genie">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full hover:bg-slate-200">
              <ArrowLeft className="h-4 w-4 text-slate-600" />
            </Button>
          </Link>
          <div className="text-sm font-medium text-slate-500">Back to Discover</div>
        </div>

        {/* Profile Header */}
        <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <h1 className="text-4xl font-black tracking-tight text-slate-900">{genius.name}</h1>
              <Badge className="rounded-full bg-indigo-600 px-4 py-1.5 text-sm font-bold text-white hover:bg-indigo-700 shadow-lg shadow-indigo-200">
                {genius.role}
              </Badge>
            </div>
            <div className="flex items-center gap-2 text-slate-600 font-medium bg-white/60 px-3 py-1 rounded-full w-fit backdrop-blur-sm">
              <MapPin className="h-4 w-4" />
              <span>{genius.university.split("•")[0]}</span>
            </div>
          </div>
          
          <Button className="gap-2 rounded-full bg-black px-8 py-6 text-lg font-bold text-white shadow-xl transition-transform hover:scale-105 hover:bg-slate-900">
            <MessageSquare className="h-5 w-5" />
            My chats
          </Button>
        </div>

        <div className="grid gap-8 md:grid-cols-[2fr_1fr]">
          {/* Left Column: Details */}
          <div className="space-y-8">
            {/* Stats Cards */}
            <div className="grid gap-4 sm:grid-cols-2">
              <InfoCard 
                icon={<GraduationCap className="h-5 w-5 text-purple-600" />}
                label="Degree"
                value={genius.degree}
                color="purple"
              />
              <InfoCard 
                icon={<Calendar className="h-5 w-5 text-pink-600" />}
                label="Year"
                value={genius.year}
                color="pink"
              />
              <InfoCard 
                icon={<BookOpen className="h-5 w-5 text-orange-600" />}
                label="Support Needed"
                value={genius.support}
                color="orange"
              />
              <InfoCard 
                icon={<MapPin className="h-5 w-5 text-blue-600" />}
                label="University"
                value={genius.university}
                color="blue"
              />
            </div>

            {/* About Section */}
            <Card className="border-none bg-white/80 shadow-xl backdrop-blur-md transition-all hover:bg-white">
              <CardHeader>
                <CardTitle className="text-xl font-bold text-slate-800 flex items-center gap-2">
                  <span>✨</span> About {genius.name.split(" ")[0]}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-base leading-relaxed text-slate-600 font-medium">
                  {genius.description}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Chart */}
          <div className="space-y-6">
            <ChartRadialStacked initialStats={genius.stats} />
          </div>
        </div>
      </div>
    </div>
  );
}

function InfoCard({ icon, label, value, color = "blue" }: { icon: React.ReactNode; label: string; value: string; color?: "blue" | "purple" | "pink" | "orange" }) {
  const colorStyles = {
    blue: "bg-blue-50 border-blue-100 hover:border-blue-300 hover:shadow-blue-100",
    purple: "bg-purple-50 border-purple-100 hover:border-purple-300 hover:shadow-purple-100",
    pink: "bg-pink-50 border-pink-100 hover:border-pink-300 hover:shadow-pink-100",
    orange: "bg-orange-50 border-orange-100 hover:border-orange-300 hover:shadow-orange-100",
  };

  const iconBgStyles = {
    blue: "bg-blue-100",
    purple: "bg-purple-100",
    pink: "bg-pink-100",
    orange: "bg-orange-100",
  };

  return (
    <div className={`flex items-start gap-4 rounded-2xl border-2 p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-md ${colorStyles[color]}`}>
      <div className={`rounded-xl p-2.5 ${iconBgStyles[color]}`}>
        {icon}
      </div>
      <div>
        <p className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</p>
        <p className="mt-1 text-sm font-bold text-slate-900">{value}</p>
      </div>
    </div>
  );
}

const chartConfig = {
  field: {
    label: "Field",
    color: "#4f46e5", // indigo-600
  },
  finances: {
    label: "Finances",
    color: "#db2777", // pink-600
  },
  behaviour: {
    label: "Behaviour",
    color: "#ea580c", // orange-600
  },
} satisfies ChartConfig;

function ChartCategoryLegend({
  field,
  finances,
  behaviour,
}: {
  field: number;
  finances: number;
  behaviour: number;
}) {
  return (
    <div className="mt-3 grid w-full grid-cols-3 gap-2 text-[11px]">
      <div className="flex items-center gap-1">
        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: "#4f46e5" }} />
        <span className="text-slate-600">Field</span>
        <span className="ml-auto font-semibold">{field}%</span>
      </div>
      <div className="flex items-center gap-1">
        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: "#db2777" }} />
        <span className="text-slate-600">Finances</span>
        <span className="ml-auto font-semibold">{finances}%</span>
      </div>
      <div className="flex items-center gap-1">
        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: "#ea580c" }} />
        <span className="text-slate-600">Behaviour</span>
        <span className="ml-auto font-semibold">{behaviour}%</span>
      </div>
    </div>
  );
}

function ChartRadialStacked({ initialStats }: { initialStats: { field: number; finances: number; behaviour: number } }) {
  const { field, finances, behaviour } = initialStats;
  const totalScore = field + finances + behaviour;

  const chartData = [
    { name: "Field", key: "field", value: field, fill: "#4f46e5" },
    { name: "Finances", key: "finances", value: finances, fill: "#db2777" },
    { name: "Behaviour", key: "behaviour", value: behaviour, fill: "#ea580c" },
  ];

  return (
    <Card className="flex flex-col border-none bg-white/80 shadow-xl backdrop-blur-md">
      <CardHeader className="items-center pb-0">
        <CardTitle>Student Profile</CardTitle>
        <CardDescription>Match Percentage Breakdown</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 items-center pb-0">
        <ChartContainer
          config={chartConfig}
          className="mx-auto w-full max-w-[250px] h-[200px] overflow-visible"
        >
          <div>
            <RadialBarChart
              width={250}
              height={200}
              cx="50%"
              cy="70%"
              innerRadius={70}
              outerRadius={120}
              startAngle={180}
              endAngle={0}
              data={chartData}
            >
              <ChartTooltip
                cursor={false}
                content={<ChartTooltipContent hideLabel />}
              />
              <RadialBar
                dataKey="value"
                background
                cornerRadius={5}
                className="stroke-transparent stroke-2"
              />
            </RadialBarChart>
          </div>
          <div className="pointer-events-none absolute inset-0 flex translate-y-4 items-center justify-center">
            <div className="text-center">
              <div className="text-xl font-bold text-slate-900">
                {totalScore}%
              </div>
              <div className="text-[11px] text-slate-500">Match</div>
            </div>
          </div>
        </ChartContainer>
      </CardContent>
      <CardFooter className="flex-col gap-2 text-sm">
        <div className="flex items-center gap-2 leading-none font-medium">
          Distribution across categories
        </div>
        <div className="text-muted-foreground leading-none text-xs text-center">
          Behaviour, field, and finances add up to 100%
        </div>
        <ChartCategoryLegend
          field={field}
          finances={finances}
          behaviour={behaviour}
        />
      </CardFooter>
    </Card>
  );
}