"use client";

import React, { useState } from "react";
import styles from "./genius.module.css";
import Link from "next/link";
import { GraduationCap, MapPin, Calendar, BookOpen, Pencil } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function GeniusPage() {
  const [activeTab, setActiveTab] = useState("Profile");

  const [profile, setProfile] = useState({
    name: "Sara Rossi",
    field: "Computer Science (BSc)",
    behaviour:
      "Highly motivated, disciplined study habits, strong interest in AI and machine learning.",
    financeNeed: "Needs support for tuition fees and living costs during the degree.",
  });

  const [isEditing, setIsEditing] = useState(false);

  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: "me" as const,
      text: "Hi Sara, I'm interested in investing in your education and future.",
      time: "10:30",
    },
    {
      id: 2,
      sender: "other" as const,
      text: "Thank you so much for reaching out, I'd love to share more about my goals.",
      time: "10:32",
    },
  ]);

  const [messageInput, setMessageInput] = useState("");

  const handleSendMessage = () => {
    if (!messageInput.trim()) return;
    const newMessage = {
      id: Date.now(),
      sender: "me" as const,
      text: messageInput.trim(),
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, newMessage]);
    setMessageInput("");
  };

  return (
    <div className={styles.root}>
      <aside className={styles.sidebar}>
        <div className={styles.sidebarTitle}>Genius</div>
        <nav className={styles.sidebarNav}>
          {["Profile", "Chats", "Edit profile"].map((tab) => (
            <button
              key={tab}
              className={`${styles.sidebarItem} ${
                activeTab === tab ? styles.sidebarItemActive : ""
              }`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </button>
          ))}
        </nav>
      </aside>

      <main className={styles.main}>
        {activeTab === "Profile" && (
          <div className={styles.discoverSection}>
            <iframe
              src="/genius/1"
              className={styles.profileFrame}
              title="Genius profile preview"
            />
          </div>
        )}

        {activeTab === "Edit profile" && (
          <div className="min-h-screen px-6 py-8 bg-slate-50">
            <div className="mx-auto max-w-4xl space-y-8">
              {/* Profile Header */}
              <div className="flex flex-col gap-6 md:flex-row md:items-start md:justify-between">
                <div className="space-y-2">
                  <div className="flex items-center gap-3">
                    {isEditing ? (
                      <input
                        value={profile.name}
                        onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                        className="text-4xl font-black tracking-tight text-slate-900 bg-white border-2 border-slate-200 rounded-lg px-3 py-1 focus:border-indigo-500 focus:outline-none"
                      />
                    ) : (
                      <h1 className="text-4xl font-black tracking-tight text-slate-900">{profile.name}</h1>
                    )}
                    <Badge className="rounded-full bg-indigo-600 px-4 py-1.5 text-sm font-bold text-white hover:bg-indigo-700 shadow-lg shadow-indigo-200">
                      STEM
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600 font-medium bg-white/60 px-3 py-1 rounded-full w-fit backdrop-blur-sm">
                    <MapPin className="h-4 w-4" />
                    <span>Università di Bologna</span>
                  </div>
                </div>
                
                <Button 
                  onClick={() => setIsEditing((prev) => !prev)}
                  className="gap-2 rounded-full bg-[#0f172a] px-8 py-6 text-lg font-bold text-white shadow-xl transition-transform hover:scale-105 hover:bg-slate-800"
                >
                  <Pencil className="h-5 w-5" />
                  {isEditing ? "Save changes" : "Edit profile"}
                </Button>
              </div>

              {/* Stats Cards */}
              <div className="grid gap-4 sm:grid-cols-2">
                <EditableInfoCard 
                  icon={<GraduationCap className="h-5 w-5 text-purple-600" />}
                  label="Degree"
                  value={profile.field}
                  color="purple"
                  isEditing={isEditing}
                  onChange={(val) => setProfile({ ...profile, field: val })}
                />
                <EditableInfoCard 
                  icon={<Calendar className="h-5 w-5 text-pink-600" />}
                  label="Year"
                  value="2nd year"
                  color="pink"
                  isEditing={false}
                />
                <EditableInfoCard 
                  icon={<BookOpen className="h-5 w-5 text-orange-600" />}
                  label="Support Needed"
                  value="Tuition & living costs"
                  color="orange"
                  isEditing={false}
                />
                <EditableInfoCard 
                  icon={<MapPin className="h-5 w-5 text-blue-600" />}
                  label="University"
                  value="Università di Bologna"
                  color="blue"
                  isEditing={false}
                />
              </div>

              {/* About Section */}
              <Card className="border-none bg-white/80 shadow-xl backdrop-blur-md transition-all hover:bg-white">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <span>✨</span> About {profile.name.split(" ")[0]}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Behaviour</p>
                    {isEditing ? (
                      <textarea
                        value={profile.behaviour}
                        onChange={(e) => setProfile({ ...profile, behaviour: e.target.value })}
                        className="w-full text-base leading-relaxed text-slate-600 font-medium bg-slate-50 border-2 border-slate-200 rounded-lg px-3 py-2 focus:border-indigo-500 focus:outline-none resize-none"
                        rows={3}
                      />
                    ) : (
                      <p className="text-base leading-relaxed text-slate-600 font-medium">
                        {profile.behaviour}
                      </p>
                    )}
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">Finance Need</p>
                    {isEditing ? (
                      <textarea
                        value={profile.financeNeed}
                        onChange={(e) => setProfile({ ...profile, financeNeed: e.target.value })}
                        className="w-full text-base leading-relaxed text-slate-600 font-medium bg-slate-50 border-2 border-slate-200 rounded-lg px-3 py-2 focus:border-indigo-500 focus:outline-none resize-none"
                        rows={3}
                      />
                    ) : (
                      <p className="text-base leading-relaxed text-slate-600 font-medium">
                        {profile.financeNeed}
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {activeTab === "Chats" && (
          <div className={styles.discoverSection}>
            <div className={styles.discoverList}>
              <h2 className={styles.discoverTitle}>My chats</h2>

              <p className={styles.discoverSubtitle}>
                Exchange messages with the student directly from here.
              </p>

              <div className={styles.chatBody}>
                <div className={styles.chatMessages}>
                  {messages.map((m) => (
                    <div
                      key={m.id}
                      className={
                        m.sender === "me" ? styles.chatRowMe : styles.chatRowOther
                      }
                    >
                      <div
                        className={`${styles.chatBubble} ${
                          m.sender === "me"
                            ? styles.chatBubbleMe
                            : styles.chatBubbleOther
                        }`}
                      >
                        <div>{m.text}</div>
                        <div className={styles.chatTime}>{m.time}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage();
                  }}
                  className={styles.chatInputRow}
                >
                  <input
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    placeholder="Type a message..."
                    className={styles.chatInput}
                  />
                  <button
                    type="submit"
                    className={styles.chatSendButton}
                  >
                    Send
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

function EditableInfoCard({ 
  icon, 
  label, 
  value, 
  color = "blue", 
  isEditing = false,
  onChange 
}: { 
  icon: React.ReactNode; 
  label: string; 
  value: string; 
  color?: "blue" | "purple" | "pink" | "orange";
  isEditing?: boolean;
  onChange?: (value: string) => void;
}) {
  const colorStyles = {
    blue: "bg-blue-50 border-blue-100 hover:border-blue-300 hover:shadow-blue-100",
    purple: "bg-purple-50 border-purple-100 hover:border-purple-300 hover:shadow-purple-100",
    pink: "bg-pink-50 border-pink-100 hover:border-pink-300 hover:shadow-pink-100",
    orange: "bg-orange-50 border-orange-100 hover:border-orange-300 hover:shadow-orange-100",
  };

  const iconBgStyles = {
    blue: "bg-blue-100",
    purple: "bg-purple-100",
    pink: "bg-pink-100",
    orange: "bg-orange-100",
  };

  return (
    <div className={`flex items-start gap-4 rounded-2xl border-2 p-5 shadow-sm transition-all hover:-translate-y-1 hover:shadow-md ${colorStyles[color]}`}>
      <div className={`rounded-xl p-2.5 ${iconBgStyles[color]}`}>
        {icon}
      </div>
      <div className="flex-1">
        <p className="text-xs font-bold uppercase tracking-wider text-slate-400">{label}</p>
        {isEditing && onChange ? (
          <input
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="mt-1 w-full text-sm font-bold text-slate-900 bg-white border border-slate-200 rounded-lg px-2 py-1 focus:border-indigo-500 focus:outline-none"
          />
        ) : (
          <p className="mt-1 text-sm font-bold text-slate-900">{value}</p>
        )}
      </div>
    </div>
  );
}