"use client";

import { useEffect, useState } from "react";
import { TrendingUp, Send, Search, MoreVertical, Phone, Video } from "lucide-react";
import { RadialBar, RadialBarChart } from "recharts";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChartConfig, ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";

const SECTIONS = ["Discover", "Chats", "Preferences"] as const;  
type SectionKey = (typeof SECTIONS)[number];
type SortKey = "field" | "finances" | "behaviour";

export default function GeniePage() {
  const [activeSection, setActiveSection] = useState<SectionKey>(
    "Discover"
  );
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<SortKey>("field");

  const handleChat = (studentName: string) => {
    setSelectedStudent(studentName);
    setActiveSection("Chats");
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      <aside className="flex w-56 flex-col gap-6 border-r bg-white px-5 py-6">
        <div className="text-sm font-semibold uppercase tracking-[0.18em] text-blue-900">
          Genie
        </div>
        <nav className="flex flex-col gap-2">
          {SECTIONS.map((item) => (
            <Button
              key={item}
              variant={item === activeSection ? "default" : "ghost"}
              className={cn(
                "w-full justify-start rounded-full px-3 py-2 text-xs font-medium",
                item === activeSection
                  ? "bg-blue-900 text-white hover:bg-blue-800"
                  : "text-slate-500 hover:bg-slate-100"
              )}
              onClick={() => setActiveSection(item)}
            >
              {item} 
            </Button>
          ))}
        </nav>
      </aside>

      <main className="flex flex-1 items-start justify-center px-6 py-6">
        {activeSection === "Discover" && (
          <DiscoverSection 
            onChat={handleChat} 
            sortBy={sortBy} 
            onSortChange={setSortBy} 
          />
        )}
        {activeSection === "Chats" && (
          <MessagesSection initialStudent={selectedStudent} />
        )}
        {activeSection === "Preferences" && <PreferencesSection />}
      </main>
    </div>
  );
}

function PreferencesSection() {
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);

  const languages = [
    "English",
    "Mandarin Chinese",
    "Hindi",
    "Spanish",
    "French",
    "Arabic",
    "Bengali",
    "Japanese",
    "Portuguese",
    "Russian",
    "German",
    "Vietnamese",
    "Italian",
    "Urdu",
  ];

  const toggleLanguage = (lang: string) => {
    setSelectedLanguages((current) =>
      current.includes(lang)
        ? current.filter((l) => l !== lang)
        : [...current, lang]
    );
  };

  return (
    <section className="flex w-full max-w-3xl flex-col gap-6 rounded-2xl border border-slate-200 bg-white px-6 py-6 shadow-sm">
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-slate-900">Search criteria</h2>
        <p className="text-xs text-slate-500">
          Describe the kind of students you are looking for and refine with filters.
        </p>
      </div>

      <div className="space-y-4 text-sm">
        <div className="space-y-2">
          <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
            Believer text
          </label>
          <textarea
            placeholder="Describe the ideal students..."
            className="min-h-[90px] w-full rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-500 focus:bg-white focus:outline-none"
          />
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Number of matches
            </label>
            <input
              type="number"
              defaultValue={10}
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Age (filter)
            </label>
            <input
              placeholder="Any"
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm placeholder:text-slate-400 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Country
            </label>
            <select className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none">
              <option>Any country</option>
              <option>Italy</option>
              <option>France</option>
              <option>Spain</option>
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Current status
            </label>
            <select className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none">
              <option>Any status</option>
              <option>Bachelor student</option>
              <option>Master student</option>
              <option>PhD</option>
            </select>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-baseline justify-between gap-2">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Languages
            </label>
            <span className="text-[11px] text-slate-400">
              Select one or more languages (optional)
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {languages.map((lang) => {
              const active = selectedLanguages.includes(lang);
              return (
                <button
                  key={lang}
                  type="button"
                  onClick={() => toggleLanguage(lang)}
                  className={cn(
                    "rounded-full px-3 py-1 text-xs border transition",
                    active
                      ? "border-blue-900 bg-blue-900 text-white"
                      : "border-slate-200 bg-slate-50 text-slate-700 hover:border-blue-300 hover:text-blue-900"
                  )}
                >
                  {lang}
                </button>
              );
            })}
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Field of study
            </label>
            <select className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none">
              <option>Any field</option>
              <option>STEM</option>
              <option>Business</option>
              <option>Humanities</option>
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Job role
            </label>
            <select className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none">
              <option>Any job</option>
              <option>Internship</option>
              <option>Part-time</option>
              <option>Full-time</option>
            </select>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Financial support per year
            </label>
            <input
              placeholder="Any"
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm placeholder:text-slate-400 focus:border-blue-500 focus:outline-none"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
              Financial support duration (years)
            </label>
            <input
              placeholder="Any"
              className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm placeholder:text-slate-400 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-medium uppercase tracking-[0.14em] text-slate-500">
            Financial support return modality
          </label>
          <select className="w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-sm focus:border-blue-500 focus:outline-none">
            <option>Any modality</option>
            <option>Grant</option>
            <option>Income share</option>
            <option>Loan</option>
          </select>
        </div>

        <div className="pt-2">
          <Button className="w-full rounded-full bg-blue-900 text-sm font-medium text-white hover:bg-blue-800">
            Discover students
          </Button>
        </div>
      </div>
    </section>
  );
}

function DiscoverSection({
  onChat,
  sortBy,
  onSortChange,
}: {
  onChat: (name: string) => void;
  sortBy: SortKey;
  onSortChange: (key: SortKey) => void;
}) {
  const students = [
    {
      id: 1,
      name: "Sara Rossi",
      role: "STEM",
      locationDegree: "Bologna • 2nd year Computer Science",
      university: "Università di Bologna",
      degree: "Computer Science (BSc)",
      year: "2nd year",
      support: "Tuition & living costs",
      description:
        "I am in my second year of Computer Science and looking for financial support to cover tuition and living costs while I focus on my studies.",
      stats: { field: 53, finances: 19, behaviour: 28 },
      chart: "stacked" as const,
    },
    {
      id: 2,
      name: "Luca Bianchi",
      role: "Business",
      locationDegree: "Milano • 1st year Economics",
      university: "Università Bocconi",
      degree: "Economics and Management",
      year: "1st year",
      support: "Accommodation & books",
      description:
        "I have just started my degree in Economics and I am looking for support to afford accommodation in Milano and the study materials I need.",
      stats: { field: 33, finances: 34, behaviour: 33 },
      chart: "simple" as const,
    },
  ];

  const sortedStudents = [...students].sort(
    (a, b) => b.stats[sortBy] - a.stats[sortBy]
  );

  return (
    <section className="w-full max-w-5xl space-y-4">
      <div className="space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-semibold">Discover students</h2>
            <p className="text-xs text-slate-500">
              Curated profiles of students looking for scholarships and support.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Sorted by</span>
            {([
              ["field", "Field"],
              ["finances", "Finances"],
              ["behaviour", "Behaviour"],
            ] as [SortKey, string][]).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => onSortChange(key)}
                className={cn(
                  "rounded-full border px-3 py-1 transition text-xs",
                  sortBy === key
                    ? "border-blue-900 bg-blue-900 text-white"
                    : "border-slate-200 bg-white text-slate-600 hover:border-blue-300 hover:text-blue-900"
                )}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {sortedStudents.map((student) => (
          <Link key={student.id} href={`/genius/${student.id}`}>
            <Card className="border-slate-200 bg-slate-50/80 transition hover:-translate-y-0.5 hover:border-blue-900 hover:bg-blue-50/60 cursor-pointer">
              <CardHeader className="space-y-1 pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">{student.name}</CardTitle>
                    <CardDescription className="text-xs text-slate-500">
                      {student.locationDegree}
                    </CardDescription>
                  </div>
                  <Badge className="rounded-full bg-blue-900 px-3 py-1 text-[11px] font-medium text-white">
                    {student.role}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="text-sm">
                <div className="grid gap-4 md:grid-cols-[minmax(0,3fr)_minmax(0,2fr)] md:items-stretch">
                  <div className="space-y-3">
                    <div className="grid gap-2 sm:grid-cols-2">
                      <Field label="University" value={student.university} />
                      <Field label="Degree" value={student.degree} />
                      <Field label="Year" value={student.year} />
                      <Field label="Support needed" value={student.support} />
                    </div>

                    <p className="mt-2 text-xs leading-relaxed text-slate-600">
                      {student.description}
                    </p>

                    <div className="pt-2">
                      <Button
                        onClick={(e) => {
                          e.preventDefault();
                          onChat(student.name);
                        }}
                        className="rounded-full border border-blue-900 bg-blue-900 px-4 py-1.5 text-xs font-medium text-white hover:bg-white hover:text-blue-900"
                      >
                        Chat with {student.name.split(" ")[0]}
                      </Button>
                    </div>
                  </div>

                  <div className="mt-4 md:mt-0">
                    {student.chart === "stacked" ? (
                      <ChartRadialStacked />
                    ) : (
                      <ChartRadialSimple />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  );
}

function MessagesSection({ initialStudent }: { initialStudent: string | null }) {
  const [activeChat, setActiveChat] = useState<string>(initialStudent || "Sara Rossi");
  const [messageInput, setMessageInput] = useState("");
  const [messages, setMessages] = useState<Record<string, { id: number; text: string; sender: "me" | "other"; time: string }[]>>({
    "Sara Rossi": [
      { id: 1, text: "Hi Sara! I saw your profile and I'm interested in your background.", sender: "me", time: "10:30 AM" },
      { id: 2, text: "Hello! Thank you for reaching out. I'm happy to answer any questions you might have.", sender: "other", time: "10:32 AM" },
    ],
    "Luca Bianchi": [
      { id: 1, text: "Hi Luca, tell me more about your economics studies.", sender: "me", time: "Yesterday" },
    ],
  });

  const handleSend = () => {
    if (!messageInput.trim()) return;
    
    const newMessage = {
      id: Date.now(),
      text: messageInput,
      sender: "me" as const,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => ({
      ...prev,
      [activeChat]: [...(prev[activeChat] || []), newMessage],
    }));
    
    setMessageInput("");
  };

  return (
    <div className="flex h-[600px] w-full max-w-5xl overflow-hidden rounded-xl border border-slate-200 bg-white shadow-sm">
      {/* Sidebar */}
      <div className="w-64 border-r border-slate-100 bg-slate-50/50">
        <div className="p-4">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-slate-400" />
            <input 
              placeholder="Search messages" 
              className="w-full rounded-md border border-slate-200 bg-white py-2 pl-8 pr-3 text-xs placeholder:text-slate-400 focus:border-blue-500 focus:outline-none"
            />
          </div>
        </div>
        <div className="flex flex-col">
          {["Sara Rossi", "Luca Bianchi"].map((name) => (
            <button
              key={name}
              onClick={() => setActiveChat(name)}
              className={cn(
                "flex items-center gap-3 px-4 py-3 text-left transition-colors",
                activeChat === name ? "bg-blue-50 border-r-2 border-blue-900" : "hover:bg-slate-100"
              )}
            >
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-slate-200 text-xs font-bold text-slate-600">
                {name.split(" ").map(n => n[0]).join("")}
              </div>
              <div className="flex-1 overflow-hidden">
                <div className="flex items-center justify-between">
                  <span className={cn("text-sm font-medium", activeChat === name ? "text-blue-900" : "text-slate-900")}>
                    {name}
                  </span>
                  <span className="text-[10px] text-slate-400">10:32</span>
                </div>
                <p className="truncate text-xs text-slate-500">
                  {messages[name]?.[messages[name].length - 1]?.text || "No messages yet"}
                </p>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex flex-1 flex-col bg-white">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100 text-xs font-bold text-blue-700">
              {activeChat.split(" ").map(n => n[0]).join("")}
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-900">{activeChat}</h3>
              <p className="text-[10px] text-slate-500">Online</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-slate-400">
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Phone className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <Video className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreVertical className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="space-y-4">
            {messages[activeChat]?.map((msg) => (
              <div
                key={msg.id}
                className={cn(
                  "flex w-full",
                  msg.sender === "me" ? "justify-end" : "justify-start"
                )}
              >
                <div
                  className={cn(
                    "max-w-[70%] rounded-2xl px-4 py-2 text-sm",
                    msg.sender === "me"
                      ? "bg-blue-900 text-white rounded-br-none"
                      : "bg-slate-100 text-slate-800 rounded-bl-none"
                  )}
                >
                  <p>{msg.text}</p>
                  <p className={cn("mt-1 text-[10px]", msg.sender === "me" ? "text-blue-200" : "text-slate-400")}>
                    {msg.time}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Input */}
        <div className="border-t border-slate-100 p-4">
          <form 
            className="flex items-center gap-2"
            onSubmit={(e) => { e.preventDefault(); handleSend(); }}
          >
            <input
              value={messageInput}
              onChange={(e) => setMessageInput(e.target.value)}
              placeholder="Type a message..."
              className="flex-1 rounded-full border border-slate-200 bg-slate-50 px-4 py-2 text-sm placeholder:text-slate-400 focus:border-blue-500 focus:bg-white focus:outline-none"
            />
            <Button 
              type="submit"
              size="icon" 
              className="h-9 w-9 rounded-full bg-blue-900 text-white hover:bg-blue-800"
            >
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-lg bg-slate-100 px-2.5 py-1.5">
      <span className="text-[10px] font-medium uppercase tracking-[0.14em] text-slate-500">
        {label}
      </span>
      <span className="text-xs text-slate-800">{value}</span>
    </div>
  );
}

const chartConfig = {
  field: {
    label: "Field",
    color: "var(--chart-1)",
  },
  finances: {
    label: "Finances",
    color: "var(--chart-2)",
  },
  behaviour: {
    label: "Behaviour",
    color: "var(--chart-3)",
  },
} satisfies ChartConfig;

function ChartCategoryLegend({
  field,
  finances,
  behaviour,
}: {
  field: number;
  finances: number;
  behaviour: number;
}) {
  return (
    <div className="mt-3 grid w-full grid-cols-3 gap-2 text-[11px]">
      <div className="flex items-center gap-1">
        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: "#2563eb" }} />
        <span className="text-slate-600">Field</span>
        <span className="ml-auto font-semibold">{field}%</span>
      </div>
      <div className="flex items-center gap-1">
        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: "#22c55e" }} />
        <span className="text-slate-600">Financies</span>
        <span className="ml-auto font-semibold">{finances}%</span>
      </div>
      <div className="flex items-center gap-1">
        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: "#f97316" }} />
        <span className="text-slate-600">Behaviour</span>
        <span className="ml-auto font-semibold">{behaviour}%</span>
      </div>
    </div>
  );
}

function generateRandomPercentages() {
  const a = Math.random();
  const b = Math.random();
  const c = Math.random();
  const sum = a + b + c || 1;

  const field = Math.round((a / sum) * 100);
  const finances = Math.round((b / sum) * 100);
  let behaviour = 100 - field - finances;

  if (behaviour < 0) {
    behaviour = 0;
  }

  return { field, finances, behaviour };
}

function ChartRadialStacked() {
  const [{ field, finances, behaviour }, setPercentages] = useState({
    field: 33,
    finances: 34,
    behaviour: 33,
  });

  useEffect(() => {
    setPercentages(generateRandomPercentages());
  }, []);

  const chartData = [
    { name: "Field", key: "field", value: field, fill: "#2563eb" },
    { name: "Financies", key: "finances", value: finances, fill: "#22c55e" },
    { name: "Behaviour", key: "behaviour", value: behaviour, fill: "#f97316" },
  ];

  const totalScore = field + finances + behaviour;

  return (
    <Card className="flex flex-col">
      <CardHeader className="items-center pb-0">
        <CardTitle>Student Profile</CardTitle>
        <CardDescription>Random percentage breakdown</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 items-center pb-0">
        <ChartContainer
          config={chartConfig}
          className="mx-auto w-full max-w-[250px] h-[200px] overflow-visible"
        >
          <div>
            <RadialBarChart
              width={250}
              height={200}
              cx="50%"
              cy="70%"
              innerRadius={70}
              outerRadius={120}
              startAngle={180}
              endAngle={0}
              data={chartData}
            >
              <ChartTooltip
                cursor={false}
                content={<ChartTooltipContent hideLabel />}
              />
              <RadialBar
                dataKey="value"
                background
                cornerRadius={5}
                className="stroke-transparent stroke-2"
              />
            </RadialBarChart>
          </div>
          <div className="pointer-events-none absolute inset-0 flex translate-y-4 items-center justify-center">
            <div className="text-center">
              <div className="text-xl font-bold text-slate-900">
                {totalScore}%
              </div>
              <div className="text-[11px] text-slate-500">Match</div>
            </div>
          </div>
        </ChartContainer>
      </CardContent>
      <CardFooter className="flex-col gap-2 text-sm">
        <div className="flex items-center gap-2 leading-none font-medium">
          Random distribution across categories
        </div>
        <div className="text-muted-foreground leading-none">
          Behaviour, field, and finances add up to 100%
        </div>
        <ChartCategoryLegend
          field={field}
          finances={finances}
          behaviour={behaviour}
        />
      </CardFooter>
    </Card>
  );
}

function ChartRadialSimple() {
  const [{ field, finances, behaviour }, setPercentages] = useState({
    field: 33,
    finances: 34,
    behaviour: 33,
  });

  useEffect(() => {
    setPercentages(generateRandomPercentages());
  }, []);

  const totalScore = field + finances + behaviour;

  const chartData = [
    { name: "Field", key: "field", value: field, fill: "#2563eb" },
    { name: "Financies", key: "finances", value: finances, fill: "#22c55e" },
    { name: "Behaviour", key: "behaviour", value: behaviour, fill: "#f97316" },
  ];

  return (
    <Card className="flex flex-col">
      <CardHeader className="items-center pb-0">
        <CardTitle>Student Profile</CardTitle>
        <CardDescription>Random percentage breakdown</CardDescription>
      </CardHeader>
      <CardContent className="flex flex-1 items-center pb-0">
        <ChartContainer
          config={chartConfig}
          className="mx-auto w-full max-w-[220px] h-[200px] overflow-visible"
        >
          <div>
            <RadialBarChart
              width={250}
              height={200}
              cx="50%"
              cy="70%"
              innerRadius={70}
              outerRadius={120}
              startAngle={180}
              endAngle={0}
              data={chartData}
            >
              <ChartTooltip
                cursor={false}
                content={<ChartTooltipContent hideLabel />}
              />
              <RadialBar
                dataKey="value"
                background
                cornerRadius={5}
                className="stroke-transparent stroke-2"
              />
            </RadialBarChart>
          </div>
          <div className="pointer-events-none absolute inset-0 flex translate-y-4 items-center justify-center">
            <div className="text-center">
              <div className="text-xl font-bold text-slate-900">
                {totalScore}%
              </div>
              <div className="text-[11px] text-slate-500">Match</div>
            </div>
          </div>
        </ChartContainer>
      </CardContent>
      <CardFooter className="flex-col gap-1 text-sm">
        <div className="flex items-center gap-2 leading-none font-medium">
          Random distribution across categories
        </div>
        <div className="text-muted-foreground leading-none text-xs">
          Behaviour, field, and finances add up to 100%
        </div>
        <ChartCategoryLegend
          field={field}
          finances={finances}
          behaviour={behaviour}
        />
      </CardFooter>
    </Card>
  );
}

