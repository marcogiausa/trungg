"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import styles from "./welcome.module.css";
import Image from "next/image";

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();

  return (
    <div className={styles.root}>
      <header className={styles.topbar}>
        <button
          className={styles.hamburger}
          aria-label="Open menu"
          onClick={() => setMenuOpen((open) => !open)}
        >
          <span />
          <span />
          <span />
        </button>

        {menuOpen && (
          <div className={styles.menuWrapper}>
            <nav className={styles.menuPanel}>
              <a href="#" className={styles.menuItem}>
                Home
              </a>
              <a href="#" className={styles.menuItem}>
                How it works
              </a>
              <a href="#" className={styles.menuItem}>
                Testimonials
              </a>
              <a href="#" className={styles.menuItem}>
                About us
              </a>
            </nav>
          </div>
        )}
      </header>

      <main className={styles.main}>
        <section className={styles.left}>
          <div className={styles.leftContent}>
            <div className={styles.brandRow}>
              <Image
                src="/lampada.png"
                alt="Lampada icon"
                className={styles.lampIcon}
                width={700}
                height={700}
              />
              <div className={styles.logo}>Genius</div>
            </div>
            
          </div>
        </section>

        <section className={styles.right}>
          <div className={styles.rightContent}>
            <h2 className={styles.sectionTitle}>Which one are you?</h2>

            <div
              className={`${styles.card} ${styles.cardLight}`}
              role="button"
              tabIndex={0}
              onClick={() => router.push("/genius")}
            >
              <div className={styles.cardHeader}>
                <div className={styles.cardTitle}> Genius</div>
                <div className={styles.cardSubtitle}>Make a wish</div>
              </div>
              <p className={styles.cardHoverText}>
                If you are a Genius, this is the right place to ask for support.
                Click here to be matched with a Genie.
              </p>
              <div className={styles.cardActions}>
                <button className={styles.cardLoginButton}>Login as Genius</button>
              </div>
            </div>

            <div className={`${styles.card} ${styles.cardDark}`} role="button" tabIndex={0}>
              <div className={styles.cardHeader}>
                <div className={styles.cardTitle}>Genie</div>
                <div className={styles.cardSubtitle}>Make a wish come true</div>
              </div>
              <p className={styles.cardHoverText}>
                If you are a Genie, this is the right place to help someone in
                need.
              </p>
              <div className={styles.cardActions}>
                <button
                  className={styles.cardLoginButton}
                  onClick={(e) => {
                    e.stopPropagation();
                    router.push("/genie");
                  }}
                >
                  Login as Genie
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className={styles.footer}>
        <nav className={styles.authLinks}>
          <a href="#" className={styles.authLink}>
            Login
          </a>
          <span className={styles.authSeparator}>|</span>
          <a href="#" className={styles.authLink}>
            Register
          </a>
        </nav>
      </footer>
    </div>
  );
}
