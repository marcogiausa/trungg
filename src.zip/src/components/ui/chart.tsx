"use client"

import * as React from "react"
import type { TooltipProps } from "recharts"
import { Tooltip as RechartsTooltip } from "recharts"

import { cn } from "@/lib/utils"

export type ChartConfig = Record<
  string,
  {
    label?: string
    color?: string
  }
>

type ChartContainerProps = {
  config: ChartConfig
  className?: string
  children: React.ReactNode
}

export function ChartContainer({ config, className, children }: ChartContainerProps) {
  const style: React.CSSProperties = {}

  let index = 1
  for (const [key, value] of Object.entries(config)) {
    if (value.color) {
      ;(style as any)[`--color-${key}`] = value.color
      ;(style as any)[`--chart-${index}`] = value.color
      index += 1
    }
  }

  return (
    <div
      data-chart
      style={style}
      className={cn("relative flex items-center justify-center", className)}
    >
      {children}
    </div>
  )
}

type ChartTooltipContentProps = TooltipProps<number, string> & {
  hideLabel?: boolean
  nameKey?: string
}

export function ChartTooltipContent({
  active,
  payload,
  label,
  hideLabel,
  nameKey,
}: ChartTooltipContentProps) {
  if (!active || !payload || !payload.length) return null

  const item = payload[0]
  const name = nameKey && item && item.payload ? (item.payload as any)[nameKey] : item.name

  return (
    <div className="rounded-md border bg-background px-3 py-2 text-xs shadow-sm">
      {!hideLabel && label && <div className="mb-1 font-medium">{label}</div>}
      <div className="flex items-center gap-2">
        <span className="h-2 w-2 rounded-full" style={{ backgroundColor: item.color }} />
        <span className="font-medium">{name}</span>
        <span className="text-muted-foreground">{item.value}</span>
      </div>
    </div>
  )
}

export function ChartTooltip(props: TooltipProps<number, string>) {
  return <RechartsTooltip {...props} />
}
